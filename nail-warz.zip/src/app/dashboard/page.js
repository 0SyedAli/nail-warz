import DashboardPanel from "./dashboard-panel/page";
export default function Dashboard({ children }) {
  return (
    <>
      <DashboardPanel />
    </>
  );
}
