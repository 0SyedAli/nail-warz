import { Providers } from "./providers";

export default function Home({ children }) {
  return (
    { children }
  );
}
