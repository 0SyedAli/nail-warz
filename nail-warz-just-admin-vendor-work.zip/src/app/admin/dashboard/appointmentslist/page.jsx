


import ManageAppointments from '@/components/MangeOrder'
import React from 'react'

const AppointmentList = () => {

  return (
    <ManageAppointments />
  )
}

export default AppointmentList